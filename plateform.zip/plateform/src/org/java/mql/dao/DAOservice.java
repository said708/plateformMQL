package org.java.mql.dao;

public interface DAOservice {

	public void setMediator(DaoMediator daoMediator);
}
