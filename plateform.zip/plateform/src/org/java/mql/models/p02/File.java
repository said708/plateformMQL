package org.java.mql.models.p02;


public class File extends AbstractFile{
	
	public File() {
	}
	
	
	public void add(AbstractFile file) {
		
	}
}
